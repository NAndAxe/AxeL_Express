const tomb = [
  { cim: "Film1", rendez: "Rendez1", megjelen: "Megjelen1", oszkar: "Igen" },
  { cim: "Film2", rendez: "Rendez2", megjelen: "Megjelen2", oszkar: "Igen" },
  { cim: "Film3", rendez: "Rendez3", megjelen: "Megjelen3", oszkar: "Nem" },
];

export default tomb;
